#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

class Connection {
public:
    int nodeA, nodeB;
    Connection(int nodeA = -1, int nodeB = -1) : nodeA(nodeA), nodeB(nodeB) {}
};

class UnionFind {
public:
    vector<int> leader, weight;

    UnionFind(int size) {
        leader.resize(size + 1);
        weight.resize(size + 1);
        for (int i = 1; i <= size; ++i) {
            leader[i] = i;
            weight[i] = 1;
        }
    }

    int findLeader(int member) {
        if (leader[member] != member) {
            leader[member] = findLeader(leader[member]);
        }
        return leader[member];
    }

    bool mergeGroups(int nodeX, int nodeY) {
        int leaderX = findLeader(nodeX);
        int leaderY = findLeader(nodeY);

        if (leaderX == leaderY) return false;

        if (weight[leaderX] > weight[leaderY]) {
            leader[leaderY] = leaderX;
            weight[leaderX] += weight[leaderY];
        } else {
            leader[leaderX] = leaderY;
            weight[leaderY] += weight[leaderX];
        }
        return true;
    }
};

long long computeMinimumSpanningTree(int nodeCount, int distanceFactor, vector<long long>& nodeValues);
void calculateMinimalEdges(int iteration, int nodeCount, int distanceFactor, UnionFind& unionFind, vector<long long>& nodeValues, vector<Connection>& optimalEdges, vector<long long>& optimalCosts);
void processMinimalEdges(int nodeCount, UnionFind& unionFind, vector<Connection>& optimalEdges, vector<long long>& optimalCosts, long long& totalCost, int& remainingComponents);

long long computeMinimumSpanningTree(int nodeCount, int distanceFactor, vector<long long>& nodeValues) {
    UnionFind unionFind(nodeCount);
    long long totalCost = 0;
    int remainingComponents = nodeCount;

    while (remainingComponents > 1) {
        vector<Connection> optimalEdges(nodeCount + 1, Connection());
        vector<long long> optimalCosts(nodeCount + 1, LLONG_MAX);

        for (int iteration = 0; iteration < 2; ++iteration) {
            calculateMinimalEdges(iteration, nodeCount, distanceFactor, unionFind, nodeValues, optimalEdges, optimalCosts);
        }

        processMinimalEdges(nodeCount, unionFind, optimalEdges, optimalCosts, totalCost, remainingComponents);
    }

    return totalCost;
}

void calculateMinimalEdges(int iteration, int nodeCount, int distanceFactor, UnionFind& unionFind, vector<long long>& nodeValues, vector<Connection>& optimalEdges, vector<long long>& optimalCosts) {
    long long bestValue = LLONG_MAX;
    int bestNode = 0;
    int temporaryBestNode = 0;
    int previousGroup = 0;
    int step = 2 * iteration - 1;

    for (int i = 1 + (nodeCount - 1) * iteration; step * i >= step * (nodeCount - (nodeCount - 1) * iteration); i -= step) {
        int currentGroup = unionFind.findLeader(i);

        if (previousGroup != 0 && previousGroup != currentGroup) {
            temporaryBestNode = bestNode;
        }

        if (temporaryBestNode != 0 && unionFind.findLeader(temporaryBestNode) != currentGroup) {
            long long edgeCost = (nodeValues[i] - (long long)step * distanceFactor * i) + 
                                 (nodeValues[temporaryBestNode] + (long long)step * distanceFactor * temporaryBestNode);
            if (edgeCost < optimalCosts[currentGroup]) {
                optimalEdges[currentGroup] = Connection(i, temporaryBestNode);
                optimalCosts[currentGroup] = edgeCost;
            }
        }

        long long adjustedValue = nodeValues[i] + (long long)step * distanceFactor * i;
        if (adjustedValue < bestValue) {
            bestNode = i;
            bestValue = adjustedValue;
        }

        previousGroup = currentGroup;
    }
}

void processMinimalEdges(int nodeCount, UnionFind& unionFind, vector<Connection>& optimalEdges, vector<long long>& optimalCosts, long long& totalCost, int& remainingComponents) {
    for (int componentIndex = 1; componentIndex <= nodeCount; ++componentIndex) {
        if (optimalEdges[componentIndex].nodeA != -1) {
            int nodeU = optimalEdges[componentIndex].nodeA;
            int nodeV = optimalEdges[componentIndex].nodeB;
            if (unionFind.mergeGroups(nodeU, nodeV)) {
                totalCost += optimalCosts[componentIndex];
                --remainingComponents;
            }
        }
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int nodeCount, distanceFactor;
    cin >> nodeCount >> distanceFactor;

    vector<long long> nodeValues(nodeCount + 1);
    for (int i = 1; i <= nodeCount; ++i) {
        cin >> nodeValues[i];
    }

    cout << computeMinimumSpanningTree(nodeCount, distanceFactor, nodeValues) << "\n";
    return 0;
}
