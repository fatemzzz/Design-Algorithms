#include <iostream>
#include <vector>

using namespace std;

// Function to load input data
void loadData(int &n, int &w, vector<long long> &vals, vector<int> &parent) {
    cin >> n >> w;
    vals.resize(n);

    for (int i = 0; i < n; ++i) {
        cin >> vals[i];
    }

    parent.resize(n, -1);
    for (int i = 0; i < n - 1; ++i) {
        int child, par;
        cin >> child >> par;
        parent[par] = child;
    }
}

// Function to initialize the DP table
void setupDP(int n, int w, vector<vector<long long>> &dp) {
    dp.assign(n, vector<long long>(w + 1, 0));
}

// Function to traverse the tree and populate the DP table
void traverseAndFill(int n, int w, const vector<long long> &vals, const vector<int> &parent,
                     vector<vector<long long>> &dp, vector<int> &status) {
    for (int curNode = n - 1; curNode > 0; --curNode) {
        if (status[curNode] == 1) {
            status[curNode] = 2;
        }

        dp[curNode][1] = max(dp[curNode][1], vals[curNode]);

        int par = parent[curNode];
        status[par] = min(w + 1, status[par] + status[curNode] - 1);

        for (int depth = status[par] - 1; depth > 0; --depth) {
            int limit = min(depth + 1, status[curNode]);

            for (int i = 0; i < limit; ++i) {
                dp[par][depth] = max(dp[par][depth], dp[par][depth - i] + dp[curNode][i]);
            }
        }
    }
}

// Function to handle the root node's DP values
void handleRoot(const vector<long long> &vals, vector<vector<long long>> &dp) {
    dp[0][1] = max(dp[0][1], vals[0]);
}

// Function to display the final result
void displayResult(const vector<vector<long long>> &dp, int w) {
    cout << dp[0][w] << "\n";
}

int main() {
    int n, w;
    vector<long long> vals;
    vector<int> parent;

    // Load data
    loadData(n, w, vals, parent);

    // Initialize DP table
    vector<vector<long long>> dp;
    setupDP(n, w, dp);

    // Status tracking for nodes
    vector<int> status(n, 1);

    // Traverse tree and populate DP table
    traverseAndFill(n, w, vals, parent, dp, status);

    // Handle root node's DP values
    handleRoot(vals, dp);

    // Display the result
    displayResult(dp, w);

    return 0;
}
