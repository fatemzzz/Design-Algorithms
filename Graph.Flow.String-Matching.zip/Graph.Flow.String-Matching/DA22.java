import java.util.*;

public class DA22 {

    // Builds the adjacency matrix for the given grid
    public static void buildAdjacencyMatrix(int[][] adjacencyMatrix, int[][] grid, int rows, int cols, int totalNodes) {
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (row == 0) {
                    adjacencyMatrix[0][col + 1]++;
                    adjacencyMatrix[col + cols + 1][totalNodes - 1]++;
                }
                int cellValue = grid[row][col];
                if (cellValue != -1) {
                    adjacencyMatrix[cellValue][col + cols + 1]++;
                }
            }
        }
    }

    // Performs Depth First Search to find an augmenting path
    public static boolean findAugmentingPath(int totalNodes, int[][] residualGraph, int source, int sink, int[] parent) {
        boolean[] visited = new boolean[totalNodes];
        Arrays.fill(visited, false);

        Stack<Integer> stack = new Stack<>();
        stack.push(source);
        visited[source] = true;
        parent[source] = -1;

        while (!stack.isEmpty()) {
            int currentNode = stack.pop();

            for (int neighbor = 0; neighbor < totalNodes; neighbor++) {
                if (!visited[neighbor] && residualGraph[currentNode][neighbor] > 0) {
                    stack.push(neighbor);
                    parent[neighbor] = currentNode;
                    visited[neighbor] = true;

                    if (neighbor == sink) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // Computes the maximum flow using the Ford-Fulkerson method
    public static int computeMaxFlow(int totalNodes, int[][] graph, int source, int sink, int[] outputIndices) {
        int[][] residualGraph = new int[totalNodes][totalNodes];
        for (int i = 0; i < totalNodes; i++) {
            System.arraycopy(graph[i], 0, residualGraph[i], 0, totalNodes);
        }

        int[] parent = new int[totalNodes];
        int maxFlow = 0;
        int middleNodeIndex = (totalNodes - 2) / 2;

        while (findAugmentingPath(totalNodes, residualGraph, source, sink, parent)) {
            int pathFlow = Integer.MAX_VALUE;

            // Find the bottleneck capacity of the path
            for (int current = sink; current != source; current = parent[current]) {
                int prev = parent[current];
                pathFlow = Math.min(pathFlow, residualGraph[prev][current]);
            }

            // Update residual capacities
            for (int current = sink; current != source; current = parent[current]) {
                int prev = parent[current];
                residualGraph[prev][current] -= pathFlow;
                residualGraph[current][prev] += pathFlow;
            }

            maxFlow += pathFlow;
        }

        // Print the matched nodes
        for (int col = middleNodeIndex + 1; col < totalNodes - 1; col++) {
            for (int row = 1; row <= middleNodeIndex; row++) {
                if (graph[row][col] > 0 && residualGraph[row][col] < graph[row][col]) {
                    System.out.print(row + " ");
                    graph[row][col]--;
                    break;
                }
            }
        }

        System.out.println();
        return maxFlow;
    }

    // Initializes the grid and output grid
    public static void initializeGrids(int[][] grid, int[][] outputGrid, Scanner scanner, int rows, int cols) {
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                grid[row][col] = scanner.nextInt();
                outputGrid[row][col] = 0;
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input dimensions
        int rows = scanner.nextInt();
        int cols = scanner.nextInt();

        int[][] grid = new int[rows][cols];
        int[][] outputGrid = new int[rows][cols];

        initializeGrids(grid, outputGrid, scanner, rows, cols);

        int totalNodes = 2 * cols + 2;
        int[][] adjacencyMatrix = new int[totalNodes][totalNodes];

        buildAdjacencyMatrix(adjacencyMatrix, grid, rows, cols, totalNodes);

        for (int row = 0; row < rows; row++) {
            int[] outputIndices = new int[cols];
            int maxFlow = computeMaxFlow(totalNodes, adjacencyMatrix, 0, totalNodes - 1, outputIndices);
        }

        scanner.close();
    }
}
