def max_assistant_performance():
    n, m = map(int, input().split())

    a = list(map(int, input().split()))
    b = list(map(int, input().split()))

    a_prime = [a[0]] + [a[i] - a[i - 1] for i in range(1, n)]
    b_prime = [b[0]] + [b[i] - b[i - 1] for i in range(1, m)]
    
    max_performance = [a_prime[0] + b_prime[0]]

    a_index = 1
    b_index = 1

    for k in range(1, n + m):
        if a_index < n and (b_index >= m or a_prime[a_index] > b_prime[b_index]):
            max_performance.append(a[a_index] + b[b_index - 1])
            a_index += 1
        elif b_index < m:
            max_performance.append(b[b_index] + a[a_index - 1])
            b_index += 1
    
    print(" ".join(map(str, max_performance)))

max_assistant_performance()
