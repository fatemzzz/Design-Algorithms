// max_length = 300001

// index_array = []
// n = int(input())
// pre_initialized_array = [0] * (n+1)
// user_array = list(map(int, input().split()))

// for i in range(n):
//     pre_initialized_array[user_array[i]] += 1

// max_sub = float('-inf')
// index_array.append(0)    

// for j in range(n):
//     if pre_initialized_array[user_array[j]]==1:
//         index_array.append(j)

// index_array.append(n)

// if len(index_array)==2:
//     print(n)
// else:
//     for j in range (1, len(index_array)):
//         if (j-1)==0:
//             max_sub = max(max_sub, index_array[j]-index_array[j-1])
//         else:
//             max_sub = max(max_sub, index_array[j]-index_array[j-1]-1)
//     if max_sub==1:
//         print (0)
//     else:

//         print(max_sub)

// # print("User array:", user_array)
// # print("index array:", index_array)
// # print("Pre-initialized array:", pre_initialized_array)





#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

using namespace std;

bool checkIsolation(int position, int lowerLimit, int upperLimit, const unordered_map<int, vector<int>>& linkData) {
    auto neighbors = linkData.at(position);
    for (size_t i = 0; i < neighbors.size(); i++) {
        if (lowerLimit <= neighbors[i] && neighbors[i] <= upperLimit) {
            return false;
        }
    }
    return true;
}

int calculateMaxRange(int lowerLimit, int upperLimit, unordered_map<int, vector<int>>& linkData) {
    int left = lowerLimit;
    int right = upperLimit;

    while (left <= right) {
        if (left == right) {
            if (checkIsolation(left, lowerLimit, upperLimit, linkData)) {
                return max(calculateMaxRange(lowerLimit, left - 1, linkData), calculateMaxRange(left + 1, upperLimit, linkData));
            }
            return upperLimit - lowerLimit + 1;
        }

        if (checkIsolation(right, lowerLimit, upperLimit, linkData)) {
            return max(calculateMaxRange(lowerLimit, right - 1, linkData), calculateMaxRange(right + 1, upperLimit, linkData));
        }
        right--;

        if (checkIsolation(left, lowerLimit, upperLimit, linkData)) {
            return max(calculateMaxRange(lowerLimit, left - 1, linkData), calculateMaxRange(left + 1, upperLimit, linkData));
        }
        left++;
    }

    return upperLimit - lowerLimit + 1;
}

int main() {
    int elementCount;
    cin >> elementCount;

    vector<int> inputData(elementCount);
    int index = 0;
    while (index < elementCount) {
        cin >> inputData[index];
        index++;
    }

    vector<pair<int, int>> arrangedData(elementCount);
    index = 0;
    while (index < elementCount) {
        arrangedData[index] = {inputData[index], index};
        index++;
    }

    sort(arrangedData.begin(), arrangedData.end());

    unordered_map<int, vector<int>> adjacencyMap;
    index = 0;
    while (index < arrangedData.size()) {
        int value = arrangedData[index].first;
        int indexPos = arrangedData[index].second;

        if (adjacencyMap.find(indexPos) == adjacencyMap.end()) {
            adjacencyMap[indexPos] = vector<int>();
        }

        if (index > 0 && arrangedData[index - 1].first == value) {
            adjacencyMap[indexPos].push_back(arrangedData[index - 1].second);
        }

        if (index < arrangedData.size() - 1 && arrangedData[index + 1].first == value) {
            adjacencyMap[indexPos].push_back(arrangedData[index + 1].second);
        }
        index++;
    }

    cout << calculateMaxRange(0, elementCount - 1, adjacencyMap) << endl;
    return 0;
}

