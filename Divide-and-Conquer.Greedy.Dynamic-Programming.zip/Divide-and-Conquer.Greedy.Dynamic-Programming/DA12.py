n = int(input())

max_a = float('-inf')
min_a = float('inf')
max_b = float('-inf')
min_b = float('inf')
indexed_numbers = []
for i in range(n):
    a, b = map(int, input().split())
    indexed_numbers.append((a, i))
    indexed_numbers.append((b, i))

    if a < b:
        a, b = b, a

    max_a = max(max_a, a)
    min_a = min(min_a, a)
    max_b = max(max_b, b)
    min_b = min(min_b, b)

indexed_numbers.sort(key=lambda x: x[0])

mark = [0 for _ in range(n)]
count = 0
l, r = 0, 0
min_len = 1e9+7
while l < len(indexed_numbers):
    if count == n:
        min_len = min(min_len, abs(indexed_numbers[r-1][0] - indexed_numbers[l][0]))
        mark[indexed_numbers[l][1]] -= 1
        if mark[indexed_numbers[l][1]] == 0:
            count -= 1
        l += 1
    elif r < len(indexed_numbers):
        if mark[indexed_numbers[r][1]] == 0:
            count += 1
        mark[indexed_numbers[r][1]] += 1
        r += 1
    else:
        break

ans1 = abs((max_a - min_a) * (max_b - min_b))
wide_range = (indexed_numbers[2*n - 1][0] - indexed_numbers[0][0])
ans2 = wide_range * min_len
print(min(ans1, ans2))