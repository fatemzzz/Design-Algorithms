#include <iostream>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <functional>
using namespace std;

class PrimeHelper {
public:
    static unordered_set<int> computePrimes(int maxLimit) {
        vector<bool> sieve(maxLimit + 1, true);
        sieve[0] = sieve[1] = false;
        int current = 2;
        while (current * current <= maxLimit) {
            if (sieve[current]) {
                int multiplier = current * current;
                while (multiplier <= maxLimit) {
                    sieve[multiplier] = false;
                    multiplier += current;
                }
            }
            current++;
        }
        unordered_set<int> primeNumbers;
        int idx = 2;
        while (idx <= maxLimit) {
            if (sieve[idx]) primeNumbers.insert(idx);
            idx++;
        }
        return primeNumbers;
    }
};

class GraphBuilder {
public:
    static unordered_map<int, vector<int>> buildGraph(const unordered_set<int>& primeSet, int nodeCount) {
        unordered_map<int, vector<int>> validConnections;
        for (int startNode = 1; startNode <= nodeCount; ++startNode) {
            for (int targetNode = 1; targetNode <= nodeCount; ++targetNode) {
                if (startNode != targetNode && primeSet.count(startNode + targetNode)) {
                    validConnections[startNode].push_back(targetNode);
                }
            }
        }
        return validConnections;
    }
};

class PathFinder {
private:
    vector<int>& path;
    const unordered_map<int, vector<int>>& validMoves;
    const unordered_set<int>& primes;
    int visitedMask;
    int totalNodes;
    vector<vector<int>>& results;

public:
    PathFinder(vector<int>& path, const unordered_map<int, vector<int>>& validMoves, const unordered_set<int>& primes, int visitedMask, int totalNodes, vector<vector<int>>& results)
        : path(path), validMoves(validMoves), primes(primes), visitedMask(visitedMask), totalNodes(totalNodes), results(results) {}

    void explorePaths(int currentDepth) {
        if (currentDepth == totalNodes) {
            if (primes.count(path[0] + path[currentDepth - 1])) {
                results.push_back(vector<int>(path.begin(), path.begin() + currentDepth));
            }
            return;
        }

        for (int nextNode : validMoves.at(path[currentDepth - 1])) {
            if (!(visitedMask & (1 << nextNode))) {
                path[currentDepth] = nextNode;
                PathFinder(path, validMoves, primes, visitedMask | (1 << nextNode), totalNodes, results).explorePaths(currentDepth + 1);
            }
        }
    }
};

class PermutationGenerator {
private:
    int nodeCount;
    unordered_set<int> primes;
    unordered_map<int, vector<int>> validMoves;
    
public:
    PermutationGenerator(int nodeCount) : nodeCount(nodeCount) {
        primes = PrimeHelper::computePrimes(2 * nodeCount);
        validMoves = GraphBuilder::buildGraph(primes, nodeCount);
    }

    vector<vector<int>> generatePermutations() {
        vector<vector<int>> validPermutations;
        vector<int> currentPath(nodeCount, 0);
        currentPath[0] = 1;

        PathFinder pathFinder(currentPath, validMoves, primes, 1 << 1, nodeCount, validPermutations);
        pathFinder.explorePaths(1);

        return validPermutations;
    }
};

int main() {
    int numNodes;
    cin >> numNodes;

    PermutationGenerator generator(numNodes);
    vector<vector<int>> permutations = generator.generatePermutations();

    for (const auto& perm : permutations) {
        for (size_t i = 0; i < perm.size(); ++i) {
            if (i > 0) cout << " ";
            cout << perm[i];
        }
        cout << endl;
    }

    return 0;
}
