#include <iostream>
#include <iomanip>
#include <vector>
#include <limits>
#include <cmath>
using namespace std;

typedef vector<double> vd;
typedef vector<vd> vvd;
typedef vector<int> vi;

const double EPS = 1e-6;

struct NegativeLPSolver {
    int m, n;
    vi B, N;
    vvd D;

    // Maximize c^T x subject to Ax <= b, x in R^n
    NegativeLPSolver(const vvd &A, const vd &b, const vd &c) : m(b.size()), n(2 * c.size()), N(n + 1), B(m), D(m + 2, vd(n + 2)) {
        vvd new_A(A.size());
        for (int i = 0; i < A.size(); i++) {
            vd row(2 * A[i].size());
            for (int j = 0; j < A[i].size(); j++) {
                row[j << 1] = A[i][j];
                row[j << 1 | 1] = -A[i][j];
            }
            new_A[i] = row;
        }
        vd new_c(n);
        for (int i = 0; i < c.size(); i++) {
            new_c[i << 1] = c[i];
            new_c[i << 1 | 1] = -c[i];
        }

        for (int i = 0; i < m; i++) for (int j = 0; j < n; j++) D[i][j] = new_A[i][j];
        for (int i = 0; i < m; i++) B[i] = n + i, D[i][n] = -1, D[i][n + 1] = b[i];
        for (int j = 0; j < n; j++) D[m][N[j] = j] = -new_c[j];
        N[n] = -1, D[m + 1][n] = 1;
    }

    void pivot(int r, int s) {
        double inv = 1.0 / D[r][s];
        for (int i = 0; i < m + 2; i++) if (i != r)
            for (int j = 0; j < n + 2; j++) if (j != s)
                D[i][j] -= D[r][j] * D[i][s] * inv;
        for (int j = 0; j < n + 2; j++) if (j != s) D[r][j] *= inv;
        for (int i = 0; i < m + 2; i++) if (i != r) D[i][s] *= -inv;
        D[r][s] = inv, swap(B[r], N[s]);
    }

    bool simplex(int phase) {
        int x = phase == 1 ? m + 1 : m;
        while (true) {
            int s = -1;
            for (int j = 0; j <= n; j++) {
                if (phase == 2 && N[j] == -1) continue;
                if (s == -1 || D[x][j] < D[x][s] || (D[x][j] == D[x][s] && N[j] < N[s])) s = j;
            }
            if (D[x][s] > -EPS) return true;
            int r = -1;
            for (int i = 0; i < m; i++) {
                if (D[i][s] < EPS) continue;
                if (r == -1 || D[i][n + 1] / D[i][s] < D[r][n + 1] / D[r][s] ||
                        (D[i][n + 1] / D[i][s]) == (D[r][n + 1] / D[r][s] && B[i] < B[r])) r = i;
            }
            if (r == -1) return false;
            pivot(r, s);
        }
    }

    double Solve(vd &x) {
        int r = 0;
        for (int i = 1; i < m; i++) if (D[i][n + 1] < D[r][n + 1]) r = i;
        if (D[r][n + 1] < -EPS) {
            pivot(r, n);
            if (!simplex(1) || D[m + 1][n + 1] < -EPS) return -numeric_limits<double>::infinity();
            for (int i = 0; i < m; i++) if (B[i] == -1) {
                int s = -1;
                for (int j = 0; j <= n; j++)
                    if (s == -1 || D[i][j] < D[i][s] || (D[i][j] == D[i][s] && N[j] < N[s])) s = j;
                pivot(i, s);
            }
        }
        if (!simplex(2)) return numeric_limits<double>::infinity();

        x = vd(n);
        for (int i = 0; i < m; i++) if (B[i] < n) x[B[i]] = D[i][n + 1];
        for (int i = 0; i < n; i += 2) x[i >> 1] = x[i] - x[i + 1];
        x.resize(n >> 1);
        return D[m][n + 1];
    }
};

int main() {
    int num_points;
    cin >> num_points;
    vector<pair<double, double>> coordinates(num_points);

    for (int idx = 0; idx < num_points; ++idx) {
        cin >> coordinates[idx].first >> coordinates[idx].second;
    }

    vd coefficients = {0, 0, -1, 1};
    vd bounds;
    vvd matrix_A;

    for (const auto &[x_coord, y_coord] : coordinates) {
        double squared_sum = x_coord * x_coord + y_coord * y_coord;

        vd row1 = {2 * x_coord, 2 * y_coord, 0, 1};
        matrix_A.push_back(row1);
        bounds.push_back(squared_sum);

        vd row2 = {-2 * x_coord, -2 * y_coord, -1, 0};
        matrix_A.push_back(row2);
        bounds.push_back(-squared_sum);
    }

    NegativeLPSolver solver(matrix_A, bounds, coefficients);
    vd solution_vector;
    double optimal_value = solver.Solve(solution_vector);

    optimal_value = -optimal_value; // Negate the value for minimization

    if (optimal_value > EPS) {
        cout << fixed << setprecision(6) << optimal_value * M_PI << endl;
    } else {
        cout << "0" << endl;
    }

    return 0;
}
