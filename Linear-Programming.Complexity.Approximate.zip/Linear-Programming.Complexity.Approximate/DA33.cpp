#include <iostream>
#include <vector>
#include <string>
using namespace std;

// This function constructs the prefix table for the given pattern
vector<int> createPrefixTable(const string& pattern)
{
    int patternSize = pattern.size();
    vector<int> prefixTable(patternSize, 0);
    int matchedLength = 0;

    int index = 1;
    while (index < patternSize)
    {
        if (pattern[index] == pattern[matchedLength])
        {
            matchedLength++;
            prefixTable[index] = matchedLength;
            index++;
        }
        else if (matchedLength > 0)
        {
            matchedLength = prefixTable[matchedLength - 1];
        }
        else
        {
            prefixTable[index] = 0;
            index++;
        }
    }

    return prefixTable;
}

// This function finds and counts the occurrences of the pattern in the text
int countPatternOccurrences(const string& pattern, const string& text)
{
    int textLength = text.size();
    vector<int> prefixTable = createPrefixTable(pattern);
    vector<int> matchedLengths(textLength, 0);
    int matchedLength = 0;

    int textIndex = 0;
    while (textIndex < textLength)
    {
        if (pattern[matchedLength] == text[textIndex])
        {
            matchedLength++;
            matchedLengths[textIndex] = matchedLength;
            textIndex++;
        }
        else if (matchedLength > 0)
        {
            matchedLength = prefixTable[matchedLength - 1];
        }
        else
        {
            matchedLengths[textIndex] = 0;
            textIndex++;
        }
    }

    int resultIndex = textLength - 1;
    int occurrences = 0;

    while (resultIndex >= 0)
    {
        if (matchedLengths[resultIndex] == 0)
        {
            return -1;
        }
        occurrences++;
        resultIndex -= matchedLengths[resultIndex];
    }

    return occurrences;
}

int main()
{
    string patt, entry;
    cin >> patt >> entry;

    int occurrenceCount = countPatternOccurrences(patt, entry);

    cout << occurrenceCount << endl;

    return 0;
}
